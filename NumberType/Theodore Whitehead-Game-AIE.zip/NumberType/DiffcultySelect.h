#pragma once
class DiffcultySelect
{
public:
	DiffcultySelect();
	int m_MIN = 1;
	int m_MAX = 100;
	
	void RangeSet();
	~DiffcultySelect();
};

